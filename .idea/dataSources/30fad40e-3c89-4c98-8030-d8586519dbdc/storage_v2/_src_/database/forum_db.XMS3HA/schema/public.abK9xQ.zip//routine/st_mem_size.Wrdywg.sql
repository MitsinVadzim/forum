create function st_mem_size(geometry) returns integer
    immutable
    strict
    language sql
as
$$
SELECT public._postgis_deprecate('ST_Mem_Size', 'ST_MemSize', '2.2.0');
    SELECT public.ST_MemSize($1);
$$;

alter function st_mem_size(geometry) owner to forum;

